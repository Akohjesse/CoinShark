class Ankanime {
   
    slideInUp(a){
         document.querySelector(`${a}`).classList.add("animate__animated", "animate__slideInUp")
    }
    moveRight(b){
         
    }
    revolve(c){

    }
    bounce(d){

    }
}