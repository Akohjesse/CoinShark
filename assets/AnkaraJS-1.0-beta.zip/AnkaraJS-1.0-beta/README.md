# AnkaraJS
A Javascript animation toolkit for easily animating your webpages

Ankara JS was created solely for the purpose of animating webpages easily with just few lines of Javascript code.
It was written using pure Es6 Vanilla Js syntax, working with classes and prototypes.

Well still currently building, it'd probably take some time before launch. SO i'd love your contributions, in order to start;
1. Check the index.js code to see the format in which the library runs on
2. Add your code to the 'help' branch
3. Reach out to me on twitter [Jesse Akoh](https://twitter.com/Jesseakoh)
